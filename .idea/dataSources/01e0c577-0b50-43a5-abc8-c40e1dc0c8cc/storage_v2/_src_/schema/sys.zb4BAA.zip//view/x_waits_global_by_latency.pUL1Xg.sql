create definer = `mariadb.sys`@localhost view x$waits_global_by_latency as
select `performance_schema`.`events_waits_summary_global_by_event_name`.`EVENT_NAME`     AS `events`,
       `performance_schema`.`events_waits_summary_global_by_event_name`.`COUNT_STAR`     AS `total`,
       `performance_schema`.`events_waits_summary_global_by_event_name`.`SUM_TIMER_WAIT` AS `total_latency`,
       `performance_schema`.`events_waits_summary_global_by_event_name`.`AVG_TIMER_WAIT` AS `avg_latency`,
       `performance_schema`.`events_waits_summary_global_by_event_name`.`MAX_TIMER_WAIT` AS `max_latency`
from `performance_schema`.`events_waits_summary_global_by_event_name`
where `performance_schema`.`events_waits_summary_global_by_event_name`.`EVENT_NAME` <> 'idle'
  and `performance_schema`.`events_waits_summary_global_by_event_name`.`SUM_TIMER_WAIT` > 0
order by `performance_schema`.`events_waits_summary_global_by_event_name`.`SUM_TIMER_WAIT` desc;

-- comment on column x$waits_global_by_latency.events not supported: Event name.

-- comment on column x$waits_global_by_latency.total not supported: Number of summarized events

-- comment on column x$waits_global_by_latency.total_latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$waits_global_by_latency.avg_latency not supported: Average wait time of the summarized events that are timed.

-- comment on column x$waits_global_by_latency.max_latency not supported: Maximum wait time of the summarized events that are timed.

