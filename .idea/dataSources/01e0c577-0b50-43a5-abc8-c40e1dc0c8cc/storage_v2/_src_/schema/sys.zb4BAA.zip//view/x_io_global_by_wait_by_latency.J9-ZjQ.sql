create definer = `mariadb.sys`@localhost view x$io_global_by_wait_by_latency as
select substring_index(`performance_schema`.`file_summary_by_event_name`.`EVENT_NAME`, '/', -2) AS `event_name`,
       `performance_schema`.`file_summary_by_event_name`.`COUNT_STAR`                           AS `total`,
       `performance_schema`.`file_summary_by_event_name`.`SUM_TIMER_WAIT`                       AS `total_latency`,
       `performance_schema`.`file_summary_by_event_name`.`AVG_TIMER_WAIT`                       AS `avg_latency`,
       `performance_schema`.`file_summary_by_event_name`.`MAX_TIMER_WAIT`                       AS `max_latency`,
       `performance_schema`.`file_summary_by_event_name`.`SUM_TIMER_READ`                       AS `read_latency`,
       `performance_schema`.`file_summary_by_event_name`.`SUM_TIMER_WRITE`                      AS `write_latency`,
       `performance_schema`.`file_summary_by_event_name`.`SUM_TIMER_MISC`                       AS `misc_latency`,
       `performance_schema`.`file_summary_by_event_name`.`COUNT_READ`                           AS `count_read`,
       `performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ`             AS `total_read`,
       ifnull(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ` /
              nullif(`performance_schema`.`file_summary_by_event_name`.`COUNT_READ`, 0), 0)     AS `avg_read`,
       `performance_schema`.`file_summary_by_event_name`.`COUNT_WRITE`                          AS `count_write`,
       `performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE`            AS `total_written`,
       ifnull(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE` /
              nullif(`performance_schema`.`file_summary_by_event_name`.`COUNT_WRITE`, 0), 0)    AS `avg_written`
from `performance_schema`.`file_summary_by_event_name`
where `performance_schema`.`file_summary_by_event_name`.`EVENT_NAME` like 'wait/io/file/%'
  and `performance_schema`.`file_summary_by_event_name`.`COUNT_STAR` > 0
order by `performance_schema`.`file_summary_by_event_name`.`SUM_TIMER_WAIT` desc;

-- comment on column x$io_global_by_wait_by_latency.total not supported: Number of summarized events

-- comment on column x$io_global_by_wait_by_latency.total_latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$io_global_by_wait_by_latency.avg_latency not supported: Average wait time of the summarized events that are timed.

-- comment on column x$io_global_by_wait_by_latency.max_latency not supported: Maximum wait time of the summarized events that are timed.

-- comment on column x$io_global_by_wait_by_latency.read_latency not supported: Total wait time of all read operations that are timed.

-- comment on column x$io_global_by_wait_by_latency.write_latency not supported: Total wait time of all write operations that are timed.

-- comment on column x$io_global_by_wait_by_latency.misc_latency not supported: Total wait time of all miscellaneous operations that are timed.

-- comment on column x$io_global_by_wait_by_latency.count_read not supported: Number of all read operations, including FGETS, FGETC, FREAD, and READ.

-- comment on column x$io_global_by_wait_by_latency.total_read not supported: Bytes read by read operations.

-- comment on column x$io_global_by_wait_by_latency.count_write not supported: Number of all write operations, including FPUTS, FPUTC, FPRINTF, VFPRINTF, FWRITE, and PWRITE.

-- comment on column x$io_global_by_wait_by_latency.total_written not supported: Bytes written by write operations.

